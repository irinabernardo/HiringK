To setup - nmp install

To start - npm run dev

Client site is hosted on http://localhost:3000
